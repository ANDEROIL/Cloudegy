mod anim;
mod config;
mod library;
mod player;
mod slide;

use std::collections::HashMap;
use std::time::{Duration, Instant};

use iced::widget::{
    button, column, container, horizontal_space, mouse_area, opaque, row, scrollable,
    slider, stack, svg, text, text_input, vertical_space, Space,
};
use iced::{
    Alignment, Background, Border, Color, Element, Font, Length, Padding, Size, Subscription,
    Theme,
};

use anim::{lerp, mix, Anim, Hover};
use config::{Config, Palette};
use library::{Group, Library, Track, UNKNOWN};
use player::{probe_duration, Player};
use slide::slide;

// Row entrance: the first rows slide in one after another.
const STAGGER_ROWS: usize = 14;
const STAGGER_STEP: f32 = 0.035; // fraction of the animation between rows
const ROW_SLIDE: f32 = 36.0; // how far a row starts from its resting place
const ROW_REST_PAD: f32 = 8.0; // resting indent, also the room to overshoot into

fn main() -> iced::Result {
    let config = config::load();

    let app = iced::application("Cloudegy", Cloudegy::update, Cloudegy::view)
        .subscription(Cloudegy::subscription)
        .theme(|_| Theme::Dark)
        .window_size(Size::new(960.0, 600.0));

    match config.font {
        Some(family) => app.default_font(Font::with_name(family)).run(),
        None => app.run(),
    }
}

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
struct Cloudegy {
    config: Config,
    library: Library,
    player: Option<Player>,
    queue: Vec<Track>,
    current: Option<usize>,
    duration: Option<Duration>,
    seeking: Option<f32>,
    section: Section,
    open_group: Option<usize>,
    search: String,
    status: String,

    // animation
    now: Instant,
    sheet_open: bool,
    settings_open: bool,
    sheet: Hover,
    view_anim: Anim,
    list_anim: Anim,
    hovers: HashMap<&'static str, Hover>,
}

impl Default for Cloudegy {
    fn default() -> Self {
        let config = config::load();
        let status = config.warning.clone().unwrap_or_default();

        Self {
            library: Library::scan(library::default_root()),
            player: Player::new(),
            queue: Vec::new(),
            current: None,
            duration: None,
            seeking: None,
            section: Section::Songs,
            open_group: None,
            search: String::new(),
            status,
            now: Instant::now(),
            sheet_open: false,
            settings_open: false,
            sheet: Hover::default(),
            view_anim: Anim::default(),
            list_anim: Anim::default(),
            hovers: HashMap::new(),
            config,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Section {
    Songs,
    Albums,
    Artists,
    Playlists,
}

impl Section {
    const ALL: [Section; 4] = [
        Section::Songs,
        Section::Albums,
        Section::Artists,
        Section::Playlists,
    ];

    fn label(self) -> &'static str {
        match self {
            Section::Songs => "Songs",
            Section::Albums => "Albums",
            Section::Artists => "Artists",
            Section::Playlists => "Playlists",
        }
    }
}

#[derive(Debug, Clone)]
enum Message {
    SetSheet(bool),
    SetSettings(bool),
    SetSection(Section),
    OpenGroup(usize),
    CloseGroup,
    SearchChanged(String),
    PlayTrack(usize),
    TogglePause,
    Next,
    Prev,
    SeekPreview(f32),
    SeekCommit,
    Tick,
    Reload,
    Frame(Instant),
    Hover(&'static str, bool),
}

// ---------------------------------------------------------------------------
// Logic
// ---------------------------------------------------------------------------
impl Cloudegy {
    fn update(&mut self, message: Message) {
        match message {
            Message::SetSheet(open) => {
                if open != self.sheet_open {
                    self.sheet_open = open;
                    let spec = self.config.sheet;
                    self.sheet.retarget(&spec, open);
                    if open {
                        self.view_anim.restart(); // the artwork pops in
                    }
                }
            }
            Message::SetSettings(open) => {
                self.settings_open = open;
                self.view_anim.restart(); // the big title pops
            }
            Message::SetSection(section) => {
                self.section = section;
                self.open_group = None;
                self.list_anim.restart();
            }
            Message::OpenGroup(i) => {
                self.open_group = Some(i);
                self.list_anim.restart();
            }
            Message::CloseGroup => {
                self.open_group = None;
                self.list_anim.restart();
            }
            Message::SearchChanged(value) => self.search = value,

            Message::PlayTrack(i) => {
                let tracks: Vec<Track> = self.visible_tracks().into_iter().cloned().collect();
                if i < tracks.len() {
                    self.queue = tracks;
                    self.start(i);
                }
            }
            Message::TogglePause => {
                if self.current.is_none() && !self.queue.is_empty() {
                    self.start(0);
                } else if let Some(player) = self.player.as_mut() {
                    player.toggle_pause();
                }
            }
            Message::Next => self.advance(),
            Message::Prev => {
                if let Some(i) = self.current {
                    self.start(i.saturating_sub(1));
                }
            }

            // Dragging the scrubber only previews; releasing does the seek.
            Message::SeekPreview(seconds) => self.seeking = Some(seconds),
            Message::SeekCommit => {
                if let Some(seconds) = self.seeking.take() {
                    if let Some(player) = self.player.as_mut() {
                        let target = Duration::from_secs_f32(seconds.max(0.0));
                        if let Err(error) = player.seek(target) {
                            self.status = format!("Can't seek in this file ({error})");
                        }
                    }
                }
            }

            Message::Tick => {
                let finished = self.player.as_ref().is_some_and(|p| p.finished());
                if self.current.is_some() && finished {
                    self.advance();
                }
            }

            // Rescans the folders and re-reads theme.toml.
            Message::Reload => {
                let root = self.library.root.clone();
                self.library = Library::scan(root);
                self.open_group = None;

                let config = config::load();
                self.status = config.warning.clone().unwrap_or_default();
                self.config = config;
                self.list_anim.restart();
            }

            Message::Frame(now) => self.now = now,
            Message::Hover(key, hovered) => {
                let spec = self.config.hover;
                self.hovers.entry(key).or_default().retarget(&spec, hovered);
            }
        }
    }

    fn subscription(&self) -> Subscription<Message> {
        // Ticks drive track changes and keep the scrubber moving.
        let tick = if self.current.is_some() {
            iced::time::every(Duration::from_millis(250)).map(|_| Message::Tick)
        } else {
            Subscription::none()
        };

        // Frames only run while something is moving, so idle costs nothing.
        let frames = if self.animating() {
            iced::window::frames().map(Message::Frame)
        } else {
            Subscription::none()
        };

        Subscription::batch([tick, frames])
    }

    fn animating(&self) -> bool {
        let c = &self.config;
        self.sheet.running(&c.sheet, self.now)
            || self.view_anim.running(&c.view, self.now)
            || self.list_anim.running(&c.list, self.now)
            || self
                .hovers
                .values()
                .any(|h| h.running(&c.hover, self.now))
    }

    fn start(&mut self, index: usize) {
        let Some(track) = self.queue.get(index) else {
            return;
        };
        let path = track.path.clone();
        let title = track.title.clone();

        let Some(player) = self.player.as_mut() else {
            self.status = "No audio device found".into();
            return;
        };

        match player.play_file(&path) {
            Ok(()) => {
                self.current = Some(index);
                self.duration = probe_duration(&path);
                self.seeking = None;
                self.status.clear();
            }
            Err(error) => {
                self.current = None;
                self.duration = None;
                self.status = format!("Can't play {title}: {error}");
            }
        }
    }

    fn advance(&mut self) {
        let Some(i) = self.current else {
            return;
        };
        if i + 1 < self.queue.len() {
            self.start(i + 1);
        } else {
            if let Some(player) = self.player.as_mut() {
                player.stop();
            }
            self.current = None;
            self.duration = None;
        }
    }

    fn groups(&self, section: Section) -> Option<&[Group]> {
        match section {
            Section::Songs => None,
            Section::Albums => Some(self.library.albums.as_slice()),
            Section::Artists => Some(self.library.artists.as_slice()),
            Section::Playlists => Some(self.library.playlists.as_slice()),
        }
    }

    /// The tracks of whatever list is open right now, before searching.
    fn base_tracks(&self) -> Option<&[Track]> {
        match (self.section, self.open_group) {
            (Section::Songs, _) => Some(self.library.songs.as_slice()),
            (section, Some(i)) => self
                .groups(section)?
                .get(i)
                .map(|group| group.tracks.as_slice()),
            _ => None,
        }
    }

    /// What the track list shows: the open list, filtered by the search box.
    fn visible_tracks(&self) -> Vec<&Track> {
        let query = self.search.trim().to_lowercase();
        self.base_tracks()
            .unwrap_or(&[])
            .iter()
            .filter(|t| {
                query.is_empty()
                    || t.title.to_lowercase().contains(&query)
                    || t.artist.to_lowercase().contains(&query)
                    || t.album.to_lowercase().contains(&query)
            })
            .collect()
    }

    fn current_track(&self) -> Option<&Track> {
        self.current.and_then(|i| self.queue.get(i))
    }

    fn readout(&self) -> String {
        if !self.status.is_empty() {
            return self.status.clone();
        }

        match self.current_track() {
            Some(t) if t.artist == UNKNOWN => t.title.clone(),
            Some(t) => format!("{} - {}", t.title, t.artist),
            None => "Nothing playing".into(),
        }
    }

    // -----------------------------------------------------------------------
    // Animation helpers
    // -----------------------------------------------------------------------
    fn hover_value(&self, key: &str) -> f32 {
        self.hovers
            .get(key)
            .map_or(0.0, |h| h.value(&self.config.hover, self.now))
    }

    /// 0 = sheet hidden, 1 = fully open.
    fn sheet_value(&self) -> f32 {
        self.sheet.value(&self.config.sheet, self.now)
    }

    /// Eased progress of the artwork pop. Overshoots past 1.0 on "pop".
    fn view_ease(&self) -> f32 {
        let spec = &self.config.view;
        spec.curve.ease(self.view_anim.progress(spec, self.now))
    }

    /// How far right a list row still has to travel to reach its place.
    fn row_offset(&self, index: usize) -> f32 {
        let spec = &self.config.list;
        let raw = self.list_anim.progress(spec, self.now);
        if raw >= 1.0 || index >= STAGGER_ROWS {
            return 0.0;
        }

        let total_delay = STAGGER_STEP * (STAGGER_ROWS - 1) as f32;
        let local = ((raw - STAGGER_STEP * index as f32) / (1.0 - total_delay)).clamp(0.0, 1.0);
        (1.0 - spec.curve.ease(local)) * ROW_SLIDE
    }

    fn slide<'a>(&self, index: usize, content: Element<'a, Message>) -> Element<'a, Message> {
        let left = (ROW_REST_PAD + self.row_offset(index)).max(0.0);
        container(content)
            .padding(Padding {
                left,
                ..Padding::ZERO
            })
            .width(Length::Fill)
            .into()
    }

    // -----------------------------------------------------------------------
    // Widgets
    // -----------------------------------------------------------------------
    fn hoverable<'a>(key: &'static str, content: Element<'a, Message>) -> Element<'a, Message> {
        mouse_area(content)
            .on_enter(Message::Hover(key, true))
            .on_exit(Message::Hover(key, false))
            .into()
    }

    /// A flat button whose hover glides in and out.
    fn flat_button<'a>(
        &self,
        key: &'static str,
        content: Element<'a, Message>,
        selected: bool,
        message: Message,
        width: Length,
        padding: [f32; 2],
    ) -> Element<'a, Message> {
        let hover = self.hover_value(key);
        let styled = button(content)
            .on_press(message)
            .style(flat(self.config.palette, self.config.radius, selected, hover))
            .padding(padding)
            .width(width)
            .into();
        Self::hoverable(key, styled)
    }

    /// An svg from the user's icons folder if they have one, else plain text.
    fn glyph<'a>(&self, icon: &str, fallback: &str, color: Color) -> Element<'a, Message> {
        match self.config.icons.get(icon) {
            Some(handle) => {
                let tint = self.config.icon_tint;
                svg(handle.clone())
                    .width(Length::Fixed(18.0))
                    .height(Length::Fixed(18.0))
                    .style(move |_theme, _status| svg::Style {
                        color: if tint { Some(color) } else { None },
                    })
                    .into()
            }
            None => text(fallback.to_string()).size(14).into(),
        }
    }

    fn icon_button<'a>(
        &self,
        icon: &str,
        key: &'static str,
        fallback: &str,
        message: Message,
    ) -> Element<'a, Message> {
        let p = self.config.palette;
        let color = mix(p.muted, p.text, self.hover_value(key));
        let content = self.glyph(icon, fallback, color);
        self.flat_button(key, content, false, message, Length::Shrink, [6.0, 10.0])
    }

    fn is_playing(&self) -> bool {
        self.player.as_ref().is_some_and(|pl| pl.is_playing())
    }

    // -----------------------------------------------------------------------
    // View
    // -----------------------------------------------------------------------
    fn view(&self) -> Element<'_, Message> {
        let p = self.config.palette;
        let t = self.sheet_value();

        // The library is always there; the now playing sheet rises over it.
        let base = if self.settings_open {
            self.settings_view()
        } else {
            self.library_view()
        };

        let body: Element<'_, Message> = if t <= 0.0 {
            base
        } else {
            stack![base, self.scrim(t), self.sheet(t)].into()
        };

        container(column![body, self.player_bar()])
            .width(Length::Fill)
            .height(Length::Fill)
            .style(move |_| container::Style::default().background(p.bg))
            .into()
    }

    fn player_bar(&self) -> Element<'_, Message> {
        let p = self.config.palette;
        let radius = self.config.radius;
        let playing = self.is_playing();

        // Icons will be drawn with canvas later; plain text for now.
        let transport = row![
            self.icon_button("prev", "prev", "<<", Message::Prev),
            self.icon_button(
                if playing { "pause" } else { "play" },
                "play",
                if playing { "pause" } else { "play" },
                Message::TogglePause,
            ),
            self.icon_button("next", "next", ">>", Message::Next),
        ]
        .spacing(4);

        // Clicking the readout raises or lowers the now playing sheet.
        let readout = self.flat_button(
            "readout",
            text(self.readout()).size(14).into(),
            false,
            Message::SetSheet(!self.sheet_open),
            Length::Fill,
            [6.0, 12.0],
        );

        let search = text_input("Search", &self.search)
            .on_input(Message::SearchChanged)
            .size(14)
            .padding([6.0, 10.0])
            .width(Length::Fixed(200.0))
            .style(move |_theme, _status| text_input::Style {
                background: Background::Color(p.panel),
                border: Border {
                    radius: radius.into(),
                    width: 0.0,
                    color: Color::TRANSPARENT,
                },
                icon: p.muted,
                placeholder: p.muted,
                value: p.text,
                selection: p.selection,
            });

        container(
            row![transport, readout, search]
                .spacing(12)
                .align_y(Alignment::Center),
        )
        .padding([10.0, 12.0])
        .width(Length::Fill)
        .style(move |_| container::Style::default().background(p.panel))
        .into()
    }

    // --- the now playing sheet ----------------------------------------------

    /// Darkens the library while the sheet is up.
    fn scrim(&self, t: f32) -> Element<'_, Message> {
        container(Space::new(Length::Fill, Length::Fill))
            .width(Length::Fill)
            .height(Length::Fill)
            .style(move |_| {
                container::Style::default().background(Color::from_rgba(0.0, 0.0, 0.0, 0.45 * t))
            })
            .into()
    }

    /// The sheet slides up from the bottom. It is laid out at full size and
    /// moved down by whatever is still hidden, so nothing gets squeezed.
    fn sheet(&self, t: f32) -> Element<'_, Message> {
        let p = self.config.palette;
        let radius = self.config.radius;

        let panel = container(self.sheet_content())
            .width(Length::Fill)
            .height(Length::Fill)
            .style(move |_| {
                container::Style::default().background(p.panel).border(Border {
                    radius: (radius * 3.0).into(),
                    width: 0.0,
                    color: Color::TRANSPARENT,
                })
            });

        slide(opaque(panel), t).into()
    }

    fn sheet_content(&self) -> Element<'_, Message> {
        let p = self.config.palette;
        let radius = self.config.radius;
        let playing = self.is_playing();

        // The artwork pops in: it starts small and overshoots on "pop" curves.
        let eased = self.view_ease();
        let size = 300.0 * lerp(0.7, 1.0, eased);
        let gap = (32.0 + (1.0 - eased) * 60.0).max(0.0);

        // The little handle at the top. Click it to lower the sheet.
        let grabber = self.flat_button(
            "grabber",
            container(Space::new(Length::Fixed(36.0), Length::Fixed(4.0)))
                .style(move |_| {
                    container::Style::default().background(p.muted).border(Border {
                        radius: 2.0.into(),
                        width: 0.0,
                        color: Color::TRANSPARENT,
                    })
                })
                .into(),
            false,
            Message::SetSheet(false),
            Length::Shrink,
            [10.0, 16.0],
        );

        let artwork = container(text("art").size(14).color(p.muted))
            .center(Length::Fill)
            .width(Length::Fixed(size))
            .height(Length::Fixed(size))
            .style(move |_| {
                container::Style::default().background(p.bg).border(Border {
                    radius: (radius * 2.0).into(),
                    width: 0.0,
                    color: Color::TRANSPARENT,
                })
            });

        let (title, subtitle) = match self.current_track() {
            Some(t) => {
                let mut sub = Vec::new();
                if t.artist != UNKNOWN {
                    sub.push(t.artist.clone());
                }
                if t.album != UNKNOWN {
                    sub.push(t.album.clone());
                }
                (t.title.clone(), sub.join("  /  "))
            }
            None => (
                "Nothing playing".to_string(),
                "Pick something from your library".to_string(),
            ),
        };

        let transport = row![
            self.icon_button("prev", "sheet-prev", "<<", Message::Prev),
            self.icon_button(
                if playing { "pause" } else { "play" },
                "sheet-play",
                if playing { "pause" } else { "play" },
                Message::TogglePause,
            ),
            self.icon_button("next", "sheet-next", ">>", Message::Next),
        ]
        .spacing(4);

        let info = column![
            text(title).size(26).color(p.text),
            text(subtitle).size(14).color(p.muted),
            vertical_space(),
            text("lyrics will go here").size(14).color(p.muted),
            vertical_space(),
            self.scrubber(),
            transport,
        ]
        .spacing(10)
        .width(Length::Fixed(420.0))
        .height(Length::Fixed(300.0));

        let back = self.flat_button(
            "leave",
            text("Back to library").size(14).into(),
            false,
            Message::SetSheet(false),
            Length::Shrink,
            [6.0, 12.0],
        );

        let top = row![
            container(back).width(Length::FillPortion(1)),
            container(grabber).center_x(Length::FillPortion(1)),
            Space::new(Length::FillPortion(1), Length::Shrink),
        ]
        .align_y(Alignment::Center);

        column![
            top,
            container(
                row![artwork, horizontal_space().width(Length::Fixed(gap)), info]
                    .align_y(Alignment::Center),
            )
            .center(Length::Fill),
        ]
        .padding(12)
        .into()
    }

    /// Elapsed time, a draggable bar, and the track's length.
    fn scrubber(&self) -> Element<'_, Message> {
        let p = self.config.palette;

        match self.duration {
            Some(total) if self.current.is_some() => {
                let total_secs = total.as_secs_f32().max(0.1);
                let position = self
                    .player
                    .as_ref()
                    .map_or(0.0, |pl| pl.position().as_secs_f32());
                let shown = self.seeking.unwrap_or(position).clamp(0.0, total_secs);

                row![
                    text(fmt_time(Duration::from_secs_f32(shown)))
                        .size(12)
                        .color(p.muted),
                    slider(0.0..=total_secs, shown, Message::SeekPreview)
                        .step(0.1_f32)
                        .height(22.0)
                        .on_release(Message::SeekCommit)
                        .style(slider_style(p)),
                    text(fmt_time(total)).size(12).color(p.muted),
                ]
                .spacing(10)
                .align_y(Alignment::Center)
                .into()
            }
            _ => row![
                text("--:--").size(12).color(p.muted),
                Space::new(Length::Fill, Length::Fixed(4.0)),
                text("--:--").size(12).color(p.muted),
            ]
            .spacing(10)
            .align_y(Alignment::Center)
            .into(),
        }
    }

    // --- settings ---------------------------------------------------------------

    fn settings_view(&self) -> Element<'_, Message> {
        let p = self.config.palette;

        // The title pops in; on "pop" curves it overshoots a little.
        let size = 64.0 * lerp(0.6, 1.0, self.view_ease());

        container(
            column![
                text("SETTINGS").size(size).color(p.text),
                self.flat_button(
                    "settings-back",
                    text("Go back").size(14).into(),
                    false,
                    Message::SetSettings(false),
                    Length::Shrink,
                    [8.0, 18.0],
                ),
            ]
            .spacing(24)
            .align_x(Alignment::Center),
        )
        .center(Length::Fill)
        .into()
    }

    // --- the library ---------------------------------------------------------

    fn library_view(&self) -> Element<'_, Message> {
        container(row![self.sidebar(), self.main_list()].height(Length::Fill))
            .width(Length::Fill)
            .height(Length::Fill)
            .into()
    }

    fn sidebar(&self) -> Element<'_, Message> {
        let p = self.config.palette;

        let mut items = column![text("Library").size(12).color(p.muted)]
            .spacing(4)
            .padding([0.0, 6.0])
            .height(Length::Fill);

        items = items.push(vertical_space().height(Length::Fixed(4.0)));

        for section in Section::ALL {
            items = items.push(self.flat_button(
                section.label(),
                text(section.label()).size(14).into(),
                self.section == section,
                Message::SetSection(section),
                Length::Fill,
                [6.0, 12.0],
            ));
        }

        items = items.push(vertical_space());

        items = items.push(self.flat_button(
            "settings",
            text("Settings").size(14).into(),
            false,
            Message::SetSettings(true),
            Length::Fill,
            [6.0, 12.0],
        ));

        let reload_color = mix(p.muted, p.text, self.hover_value("reload"));
        items = items.push(self.flat_button(
            "reload",
            self.glyph("reload", "Reload", reload_color),
            false,
            Message::Reload,
            Length::Fill,
            [6.0, 12.0],
        ));

        container(items)
            .padding(12)
            .width(Length::Fixed(190.0))
            .height(Length::Fill)
            .style(move |_| container::Style::default().background(p.sidebar))
            .into()
    }

    fn main_list(&self) -> Element<'_, Message> {
        // Albums / Artists / Playlists show their folders first.
        if self.section != Section::Songs && self.open_group.is_none() {
            return self.group_list();
        }
        self.track_list()
    }

    fn group_list(&self) -> Element<'_, Message> {
        let p = self.config.palette;
        let radius = self.config.radius;
        let groups = self.groups(self.section).unwrap_or(&[]);

        let content: Element<'_, Message> = if groups.is_empty() {
            self.empty_state(&format!("No {} yet.", self.section.label().to_lowercase()))
        } else {
            let rows = groups.iter().enumerate().map(|(i, group)| {
                let entry = button(
                    row![
                        text(group.name.as_str())
                            .size(14)
                            .color(p.text)
                            .width(Length::Fill),
                        text(format!("{} tracks", group.tracks.len()))
                            .size(12)
                            .color(p.muted),
                    ]
                    .align_y(Alignment::Center),
                )
                .on_press(Message::OpenGroup(i))
                .style(flat_native(p, radius, false))
                .padding([8.0, 12.0])
                .width(Length::Fill)
                .into();

                self.slide(i, entry)
            });

            scrollable(column(rows).spacing(2))
                .height(Length::Fill)
                .into()
        };

        column![text(self.section.label()).size(18).color(p.text), content]
            .spacing(12)
            .padding(16)
            .width(Length::Fill)
            .height(Length::Fill)
            .into()
    }

    fn track_list(&self) -> Element<'_, Message> {
        let p = self.config.palette;
        let radius = self.config.radius;
        let tracks = self.visible_tracks();
        let playing_path = self.current_track().map(|t| &t.path);

        // Title line, with a back button when inside a folder.
        let title: Element<'_, Message> = match self.open_group {
            Some(i) => {
                let name = self
                    .groups(self.section)
                    .and_then(|g| g.get(i))
                    .map(|g| g.name.as_str())
                    .unwrap_or("");
                row![
                    self.flat_button(
                        "back",
                        text("<").size(14).into(),
                        false,
                        Message::CloseGroup,
                        Length::Shrink,
                        [4.0, 10.0],
                    ),
                    text(name).size(18).color(p.text),
                ]
                .spacing(8)
                .align_y(Alignment::Center)
                .into()
            }
            None => text(self.section.label()).size(18).color(p.text).into(),
        };

        let header = row![
            text("Title").size(12).color(p.muted).width(Length::FillPortion(4)),
            text("Artist").size(12).color(p.muted).width(Length::FillPortion(3)),
            text("Album").size(12).color(p.muted).width(Length::FillPortion(3)),
            text("Time").size(12).color(p.muted).width(Length::FillPortion(1)),
        ]
        .spacing(12)
        .padding([0.0, 12.0 + ROW_REST_PAD]);

        let content: Element<'_, Message> = if tracks.is_empty() {
            let message = if self.search.trim().is_empty() {
                format!("No music yet. Drop files into {}", self.library.root.display())
            } else {
                "Nothing matches your search.".to_string()
            };
            self.empty_state(&message)
        } else {
            let rows = tracks.into_iter().enumerate().map(|(i, t)| {
                let is_current = playing_path == Some(&t.path);
                let entry = button(
                    row![
                        text(t.title.as_str()).size(14).color(p.text).width(Length::FillPortion(4)),
                        text(t.artist.as_str()).size(14).color(p.muted).width(Length::FillPortion(3)),
                        text(t.album.as_str()).size(14).color(p.muted).width(Length::FillPortion(3)),
                        text("--:--").size(14).color(p.muted).width(Length::FillPortion(1)),
                    ]
                    .spacing(12),
                )
                .on_press(Message::PlayTrack(i))
                .style(flat_native(p, radius, is_current))
                .padding([6.0, 12.0])
                .width(Length::Fill)
                .into();

                self.slide(i, entry)
            });

            scrollable(column(rows).spacing(2))
                .height(Length::Fill)
                .into()
        };

        column![title, header, content]
            .spacing(12)
            .padding(16)
            .width(Length::Fill)
            .height(Length::Fill)
            .into()
    }

    fn empty_state(&self, message: &str) -> Element<'_, Message> {
        container(
            text(message.to_string())
                .size(14)
                .color(self.config.palette.muted),
        )
        .center(Length::Fill)
        .into()
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
fn fmt_time(duration: Duration) -> String {
    let secs = duration.as_secs();
    format!("{}:{:02}", secs / 60, secs % 60)
}

// ---------------------------------------------------------------------------
// Styles
// ---------------------------------------------------------------------------

/// Button whose hover colour is driven by our own animation (`hover` is 0..1).
fn flat(
    p: Palette,
    radius: f32,
    selected: bool,
    hover: f32,
) -> impl Fn(&Theme, button::Status) -> button::Style {
    move |_theme, status| {
        let pressed = matches!(status, button::Status::Pressed);
        let hover_bg = Color { a: 0.0, ..p.hover };

        let background = if selected || pressed {
            p.selected
        } else {
            mix(hover_bg, p.hover, hover)
        };

        button::Style {
            background: Some(Background::Color(background)),
            text_color: if selected {
                p.text
            } else {
                mix(p.muted, p.text, hover)
            },
            border: Border {
                radius: radius.into(),
                width: 0.0,
                color: Color::TRANSPARENT,
            },
            ..button::Style::default()
        }
    }
}

/// Same look, but hover comes straight from iced. Used for list rows.
fn flat_native(
    p: Palette,
    radius: f32,
    selected: bool,
) -> impl Fn(&Theme, button::Status) -> button::Style {
    move |_theme, status| {
        let background = match (selected, status) {
            (true, _) => Some(Background::Color(p.selected)),
            (false, button::Status::Hovered) => Some(Background::Color(p.hover)),
            (false, button::Status::Pressed) => Some(Background::Color(p.selected)),
            _ => None,
        };

        button::Style {
            background,
            text_color: if selected { p.text } else { p.muted },
            border: Border {
                radius: radius.into(),
                width: 0.0,
                color: Color::TRANSPARENT,
            },
            ..button::Style::default()
        }
    }
}

/// The scrubber: a thin bar that fills with the text colour.
fn slider_style(p: Palette) -> impl Fn(&Theme, slider::Status) -> slider::Style {
    move |_theme, status| {
        let handle = match status {
            slider::Status::Hovered | slider::Status::Dragged => p.text,
            _ => p.muted,
        };

        slider::Style {
            rail: slider::Rail {
                backgrounds: (Background::Color(p.text), Background::Color(p.selected)),
                width: 4.0,
                border: Border {
                    radius: 2.0.into(),
                    width: 0.0,
                    color: Color::TRANSPARENT,
                },
            },
            handle: slider::Handle {
                shape: slider::HandleShape::Circle { radius: 6.0 },
                background: Background::Color(handle),
                border_width: 0.0,
                border_color: Color::TRANSPARENT,
            },
        }
    }
}
