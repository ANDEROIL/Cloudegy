use std::fs::File;
use std::path::Path;
use std::time::Duration;

use rodio::{Decoder, OutputStream, OutputStreamHandle, Sink};

/// Thin wrapper around rodio. One sink per track.
pub struct Player {
    _stream: OutputStream, // must stay alive or the audio stops
    handle: OutputStreamHandle,
    sink: Option<Sink>,
}

impl Player {
    /// Returns None when no audio device can be opened.
    pub fn new() -> Option<Self> {
        let (stream, handle) = OutputStream::try_default().ok()?;
        Some(Self {
            _stream: stream,
            handle,
            sink: None,
        })
    }

    pub fn play_file(&mut self, path: &Path) -> Result<(), String> {
        self.stop();

        let file = File::open(path).map_err(|e| e.to_string())?;
        // Decoder::try_from(File) knows the file length, which seeking needs.
        let source = Decoder::try_from(file).map_err(|e| e.to_string())?;
        let sink = Sink::try_new(&self.handle).map_err(|e| e.to_string())?;
        sink.append(source);
        self.sink = Some(sink);
        Ok(())
    }

    pub fn toggle_pause(&mut self) {
        if let Some(sink) = &self.sink {
            if sink.is_paused() {
                sink.play();
            } else {
                sink.pause();
            }
        }
    }

    pub fn is_playing(&self) -> bool {
        self.sink
            .as_ref()
            .is_some_and(|s| !s.is_paused() && !s.empty())
    }

    /// True once the current track has played to the end.
    pub fn finished(&self) -> bool {
        self.sink.as_ref().is_some_and(|s| s.empty())
    }

    /// How far into the current track we are.
    pub fn position(&self) -> Duration {
        self.sink.as_ref().map_or(Duration::ZERO, |s| s.get_pos())
    }

    pub fn seek(&mut self, to: Duration) -> Result<(), String> {
        match &self.sink {
            Some(sink) => sink.try_seek(to).map_err(|e| format!("{e:?}")),
            None => Ok(()),
        }
    }

    pub fn stop(&mut self) {
        if let Some(sink) = self.sink.take() {
            sink.stop();
        }
    }
}

/// Reads a file's length from its header. None if it can't be determined.
pub fn probe_duration(path: &Path) -> Option<Duration> {
    use lofty::file::AudioFile;

    let tagged = lofty::read_from_path(path).ok()?;
    let duration = tagged.properties().duration();
    if duration.is_zero() {
        None
    } else {
        Some(duration)
    }
}
