//! ~/.config/cloudegy/theme.toml
//! Colors, shape, font, icons, curves and animations. Anything missing falls
//! back to a default, so a theme file can be as small as one line.

use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::time::Duration;

use iced::widget::svg;
use iced::Color;
use serde::Deserialize;

use crate::anim::{Bezier, Spec};

#[derive(Debug, Clone, Copy)]
pub struct Palette {
    pub bg: Color,
    pub sidebar: Color,
    pub panel: Color,
    pub hover: Color,
    pub selected: Color,
    pub text: Color,
    pub muted: Color,
    pub selection: Color,
}

impl Default for Palette {
    fn default() -> Self {
        Self {
            bg: Color::from_rgb(0.169, 0.169, 0.169),       // #2b2b2b
            sidebar: Color::from_rgb(0.149, 0.149, 0.149),  // #262626
            panel: Color::from_rgb(0.200, 0.200, 0.200),    // #333333
            hover: Color::from_rgb(0.227, 0.227, 0.227),    // #3a3a3a
            selected: Color::from_rgb(0.267, 0.267, 0.267), // #444444
            text: Color::from_rgb(0.831, 0.831, 0.831),     // #d4d4d4
            muted: Color::from_rgb(0.620, 0.620, 0.620),    // #9e9e9e
            selection: Color::from_rgba(1.0, 1.0, 1.0, 0.20),
        }
    }
}

#[derive(Debug, Clone)]
pub struct Config {
    pub palette: Palette,
    pub radius: f32,
    pub font: Option<&'static str>,
    pub view: Spec,
    pub list: Spec,
    pub hover: Spec,
    pub sheet: Spec,
    pub icons: HashMap<&'static str, svg::Handle>,
    pub icon_tint: bool,
    /// Set when theme.toml could not be read; the app still runs on defaults.
    pub warning: Option<String>,
}

const DEFAULT_THEME: &str = r##"# Cloudegy theme. Edit, save, then click Reload in the sidebar.

[colors]
background = "#2b2b2b"
sidebar    = "#262626"
panel      = "#333333"
hover      = "#3a3a3a"
selected   = "#444444"
text       = "#d4d4d4"
muted      = "#9e9e9e"
selection  = "#ffffff33"

[shape]
radius = 6

[font]
# Needs a restart. Handy when a title shows empty squares.
# family = "Noto Sans"

[icons]
# Put prev.svg, play.svg, pause.svg, next.svg and reload.svg in the icons
# folder next to this file and they replace the text buttons.
# tint = true recolors them to match the theme.
tint = true

# Curves work like Hyprland: two control points, [[x1, y1], [x2, y2]].
# A y above 1.0 overshoots and settles back, which is the cartoon feel.
[curves]
gnome  = { points = [[0.18, 0.85], [0.25, 1.0]] }
pop    = { points = [[0.34, 1.56], [0.64, 1.0]] }
boing  = { points = [[0.30, 2.00], [0.50, 1.0]] }
glide  = { points = [[0.22, 1.0], [0.36, 1.0]] }
linear = { points = [[0.0, 0.0], [1.0, 1.0]] }

# scale slows everything down (2.0 = twice as slow) or speeds it up (0.5).
[motion]
scale = 1.0

# speed is in deciseconds like Hyprland: 3 means 300ms.
# view  = the artwork popping in when the now playing sheet opens
# sheet = the now playing sheet sliding up from the bottom
# list  = rows sliding in when a list opens
# hover = buttons lighting up
[animations]
view  = { enabled = true, speed = 3.0, curve = "pop" }
list  = { enabled = true, speed = 4.0, curve = "pop" }
hover = { enabled = true, speed = 1.2, curve = "gnome" }
sheet = { enabled = true, speed = 5.0, curve = "glide" }
"##;

pub fn config_dir() -> PathBuf {
    if let Ok(dir) = std::env::var("XDG_CONFIG_HOME") {
        if !dir.is_empty() {
            return PathBuf::from(dir).join("cloudegy");
        }
    }
    let home = std::env::var("HOME").unwrap_or_else(|_| ".".into());
    PathBuf::from(home).join(".config").join("cloudegy")
}

// --- the shape of theme.toml -------------------------------------------------

#[derive(Deserialize, Default)]
#[serde(default)]
struct Raw {
    colors: RawColors,
    shape: RawShape,
    font: RawFont,
    icons: RawIcons,
    motion: RawMotion,
    curves: HashMap<String, RawCurve>,
    animations: HashMap<String, RawAnim>,
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawColors {
    background: Option<String>,
    sidebar: Option<String>,
    panel: Option<String>,
    hover: Option<String>,
    selected: Option<String>,
    text: Option<String>,
    muted: Option<String>,
    selection: Option<String>,
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawShape {
    radius: Option<f32>,
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawFont {
    family: Option<String>,
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawIcons {
    tint: Option<bool>,
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawMotion {
    scale: Option<f32>,
}

#[derive(Deserialize)]
struct RawCurve {
    points: [[f32; 2]; 2],
}

#[derive(Deserialize, Default)]
#[serde(default)]
struct RawAnim {
    enabled: Option<bool>,
    speed: Option<f32>,
    curve: Option<String>,
}

// --- loading -----------------------------------------------------------------

pub fn load() -> Config {
    let dir = config_dir();
    let _ = fs::create_dir_all(dir.join("icons"));

    let path = dir.join("theme.toml");
    if !path.exists() {
        let _ = fs::write(&path, DEFAULT_THEME);
    }

    let mut warning = None;
    let raw = match fs::read_to_string(&path) {
        Ok(text) => match toml::from_str::<Raw>(&text) {
            Ok(raw) => raw,
            Err(error) => {
                let first_line = error.to_string().lines().next().unwrap_or("").to_string();
                warning = Some(format!("theme.toml: {first_line}"));
                Raw::default()
            }
        },
        Err(error) => {
            warning = Some(format!("theme.toml: {error}"));
            Raw::default()
        }
    };

    // Palette
    let defaults = Palette::default();
    let pick = |value: &Option<String>, fallback: Color| {
        value.as_deref().and_then(parse_hex).unwrap_or(fallback)
    };
    let c = &raw.colors;
    let palette = Palette {
        bg: pick(&c.background, defaults.bg),
        sidebar: pick(&c.sidebar, defaults.sidebar),
        panel: pick(&c.panel, defaults.panel),
        hover: pick(&c.hover, defaults.hover),
        selected: pick(&c.selected, defaults.selected),
        text: pick(&c.text, defaults.text),
        muted: pick(&c.muted, defaults.muted),
        selection: pick(&c.selection, defaults.selection),
    };

    // Curves: built-ins first, then whatever the user defined.
    let mut curves: HashMap<String, Bezier> = HashMap::new();
    curves.insert("linear".into(), Bezier::LINEAR);
    curves.insert("gnome".into(), Bezier::new(0.18, 0.85, 0.25, 1.0));
    curves.insert("pop".into(), Bezier::new(0.34, 1.56, 0.64, 1.0));
    curves.insert("glide".into(), Bezier::new(0.22, 1.0, 0.36, 1.0));
    for (name, curve) in raw.curves {
        let [[x1, y1], [x2, y2]] = curve.points;
        curves.insert(name, Bezier::new(x1, y1, x2, y2));
    }

    // Animations
    let scale = raw.motion.scale.unwrap_or(1.0).clamp(0.1, 10.0);
    let spec = |leaf: &str, enabled: bool, speed: f32, curve: &str| -> Spec {
        let user = raw.animations.get(leaf);
        let enabled = user.and_then(|a| a.enabled).unwrap_or(enabled);
        let speed = user.and_then(|a| a.speed).unwrap_or(speed).max(0.0);
        let name = user.and_then(|a| a.curve.as_deref()).unwrap_or(curve);
        Spec {
            enabled,
            duration: Duration::from_secs_f32(speed * 0.1 * scale),
            curve: curves.get(name).copied().unwrap_or(Bezier::LINEAR),
        }
    };
    let view = spec("view", true, 3.0, "pop");
    let list = spec("list", true, 4.0, "pop");
    let hover = spec("hover", true, 1.2, "gnome");
    let sheet = spec("sheet", true, 5.0, "glide");

    // Font. Leaked on purpose: iced wants a &'static str and this is tiny.
    let font = raw
        .font
        .family
        .filter(|f| !f.trim().is_empty())
        .map(|f| &*Box::leak(f.into_boxed_str()));

    // Icons: any of these files in the icons folder replace the text buttons.
    let mut icons = HashMap::new();
    for name in ["prev", "play", "pause", "next", "reload"] {
        let icon_path = dir.join("icons").join(format!("{name}.svg"));
        if icon_path.is_file() {
            icons.insert(name, svg::Handle::from_path(icon_path));
        }
    }

    Config {
        palette,
        radius: raw.shape.radius.unwrap_or(6.0).max(0.0),
        font,
        view,
        list,
        hover,
        sheet,
        icons,
        icon_tint: raw.icons.tint.unwrap_or(true),
        warning,
    }
}

fn parse_hex(value: &str) -> Option<Color> {
    let hex = value.trim().trim_start_matches('#');
    let byte = |i: usize| -> Option<u8> { u8::from_str_radix(hex.get(i..i + 2)?, 16).ok() };

    match hex.len() {
        6 => Some(Color::from_rgb8(byte(0)?, byte(2)?, byte(4)?)),
        8 => Some(Color::from_rgba8(
            byte(0)?,
            byte(2)?,
            byte(4)?,
            byte(6)? as f32 / 255.0,
        )),
        _ => None,
    }
}
