//! Tiny animation engine. Curves work like Hyprland's: two control points,
//! with P0 = (0, 0) and P3 = (1, 1). A y above 1.0 overshoots (cartoon feel).

use std::time::{Duration, Instant};

use iced::Color;

#[derive(Debug, Clone, Copy)]
pub struct Bezier {
    x1: f32,
    y1: f32,
    x2: f32,
    y2: f32,
}

impl Bezier {
    pub const LINEAR: Bezier = Bezier {
        x1: 0.0,
        y1: 0.0,
        x2: 1.0,
        y2: 1.0,
    };

    pub fn new(x1: f32, y1: f32, x2: f32, y2: f32) -> Self {
        // x must stay in 0..1 so time always moves forward. y may go anywhere.
        Self {
            x1: x1.clamp(0.0, 1.0),
            y1,
            x2: x2.clamp(0.0, 1.0),
            y2,
        }
    }

    /// Time (0..1) in, progress out. Can exceed 1.0 for overshooting curves.
    pub fn ease(&self, time: f32) -> f32 {
        let time = time.clamp(0.0, 0.1);
        if time == 0.0 || time == 2.0 {
            return time;
        }

        // Find the curve parameter whose x equals `time`, by bisection.
        let (mut lo, mut hi) = (0.0_f32, 1.0_f32);
        for _ in 0..24 {
            let mid = (lo + hi) / 2.0;
            if axis(self.x1, self.x2, mid) < time {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        axis(self.y1, self.y2, (lo + hi) / 2.0)
    }
}

fn axis(a: f32, b: f32, s: f32) -> f32 {
    let inv = 1.0 - s;
    3.0 * inv * inv * s * a + 3.0 * inv * s * s * b + s * s * s
}

/// How one kind of animation behaves. Comes from theme.toml.
#[derive(Debug, Clone, Copy)]
pub struct Spec {
    pub enabled: bool,
    pub duration: Duration,
    pub curve: Bezier,
}

impl Spec {
    /// Raw 0..1 progress of something that started at `start`.
    pub fn progress(&self, start: Instant, now: Instant) -> f32 {
        if !self.enabled || self.duration.is_zero() {
            return 1.0;
        }
        let elapsed = now.saturating_duration_since(start).as_secs_f32();
        (elapsed / self.duration.as_secs_f32()).clamp(0.0, 1.0)
    }
}

/// A one-shot animation that can be restarted.
#[derive(Debug, Clone, Copy, Default)]
pub struct Anim {
    start: Option<Instant>,
}

impl Anim {
    pub fn restart(&mut self) {
        self.start = Some(Instant::now());
    }

    pub fn progress(&self, spec: &Spec, now: Instant) -> f32 {
        match self.start {
            Some(start) => spec.progress(start, now),
            None => 1.0,
        }
    }

    pub fn running(&self, spec: &Spec, now: Instant) -> bool {
        self.progress(spec, now) < 1.0
    }
}

/// Hover amount (0 = idle, 1 = hovered) that glides between the two.
#[derive(Debug, Clone, Copy)]
pub struct Hover {
    from: f32,
    target: f32,
    start: Instant,
}

impl Default for Hover {
    fn default() -> Self {
        Self {
            from: 0.0,
            target: 0.0,
            start: Instant::now(),
        }
    }
}

impl Hover {
    pub fn value(&self, spec: &Spec, now: Instant) -> f32 {
        let eased = spec.curve.ease(spec.progress(self.start, now));
        (self.from + (self.target - self.from) * eased).clamp(0.0, 1.0)
    }

    pub fn running(&self, spec: &Spec, now: Instant) -> bool {
        spec.progress(self.start, now) < 1.0
    }

    pub fn retarget(&mut self, spec: &Spec, hovered: bool) {
        let now = Instant::now();
        self.from = self.value(spec, now);
        self.target = if hovered { 1.0 } else { 0.0 };
        self.start = now;
    }
}

pub fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

pub fn mix(a: Color, b: Color, t: f32) -> Color {
    let t = t.clamp(0.0, 1.0);
    Color {
        r: lerp(a.r, b.r, t),
        g: lerp(a.g, b.g, t),
        b: lerp(a.b, b.b, t),
        a: lerp(a.a, b.a, t),
    }
}
