//! The folders are the database.
//!
//! ~/Music/Cloudegy/
//!   Songs/       loose tracks
//!   Albums/      one folder per album
//!   Artists/     one folder per artist (album folders inside are fine)
//!   Playlists/   one folder per playlist (folders inside folders are fine)
//!
//! Set CLOUDEGY_DIR to use a different root.fuck this shit

use std::fs;
use std::path::{Path, PathBuf};

pub const UNKNOWN: &str = "-";

const AUDIO_EXTENSIONS: [&str; 7] = ["mp3", "flac", "ogg", "oga", "wav", "m4a", "aac"];
const MAX_DEPTH: usize = 8;

#[derive(Debug, Clone)]
pub struct Track {
    pub path: PathBuf,
    pub title: String,
    pub artist: String,
    pub album: String,
}

#[derive(Debug, Clone)]
pub struct Group {
    pub name: String,
    pub tracks: Vec<Track>,
}

#[derive(Debug, Clone, Default)]
pub struct Library {
    pub root: PathBuf,
    pub songs: Vec<Track>,
    pub albums: Vec<Group>,
    pub artists: Vec<Group>,
    pub playlists: Vec<Group>,
}

#[derive(Clone, Copy)]
enum Kind {
    Album,
    Artist,
    Playlist,
}

pub fn default_root() -> PathBuf {
    if let Ok(dir) = std::env::var("CLOUDEGY_DIR") {
        return PathBuf::from(dir);
    }
    let home = std::env::var("HOME").unwrap_or_else(|_| ".".into());
    PathBuf::from(home).join("Music").join("Cloudegy")
}

impl Library {
    pub fn scan(root: PathBuf) -> Library {
        for name in ["Songs", "Albums", "Artists", "Playlists"] {
            let _ = fs::create_dir_all(root.join(name));
        }

        let songs = audio_files(&root.join("Songs"))
            .into_iter()
            .map(|p| track(p, UNKNOWN, UNKNOWN))
            .collect();

        Library {
            songs,
            albums: groups(&root.join("Albums"), Kind::Album),
            artists: groups(&root.join("Artists"), Kind::Artist),
            playlists: groups(&root.join("Playlists"), Kind::Playlist),
            root,
        }
    }
}

fn groups(dir: &Path, kind: Kind) -> Vec<Group> {
    let mut out = Vec::new();

    for sub in sorted_subdirs(dir) {
        let name = file_name(&sub);
        let tracks = audio_files(&sub)
            .into_iter()
            .map(|path| match kind {
                Kind::Album => track(path, UNKNOWN, &name),
                Kind::Artist => {
                    let album = album_under(&sub, &path);
                    track(path, &name, &album)
                }
                Kind::Playlist => track(path, UNKNOWN, UNKNOWN),
            })
            .collect();

        out.push(Group { name, tracks });
    }

    out
}

/// For Artists/<artist>/<album>/song.mp3 the album is the parent folder.
fn album_under(artist_dir: &Path, file: &Path) -> String {
    match file.parent() {
        Some(parent) if parent != artist_dir => file_name(parent),
        _ => UNKNOWN.to_string(),
    }
}

fn track(path: PathBuf, artist: &str, album: &str) -> Track {
    let title = path
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "Untitled".into());

    Track {
        path,
        title,
        artist: artist.to_string(),
        album: album.to_string(),
    }
}

fn file_name(path: &Path) -> String {
    path.file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default()
}

fn sorted_subdirs(dir: &Path) -> Vec<PathBuf> {
    let Ok(entries) = fs::read_dir(dir) else {
        return Vec::new();
    };

    let mut dirs: Vec<PathBuf> = entries
        .flatten()
        .map(|e| e.path())
        .filter(|p| p.is_dir() && !file_name(p).starts_with('.'))
        .collect();

    dirs.sort_by_key(|p| file_name(p).to_lowercase());
    dirs
}

fn audio_files(dir: &Path) -> Vec<PathBuf> {
    let mut files = Vec::new();
    collect(dir, 0, &mut files);
    files.sort_by_key(|p| p.to_string_lossy().to_lowercase());
    files
}

fn collect(dir: &Path, depth: usize, out: &mut Vec<PathBuf>) {
    if depth > MAX_DEPTH {
        return;
    }
    let Ok(entries) = fs::read_dir(dir) else {
        return;
    };

    for entry in entries.flatten() {
        let path = entry.path();
        if file_name(&path).starts_with('.') {
            continue;
        }
        if path.is_dir() {
            collect(&path, depth + 1, out);
        } else if is_audio(&path) {
            out.push(path);
        }
    }
}

fn is_audio(path: &Path) -> bool {
    path.extension()
        .and_then(|e| e.to_str())
        .map(|e| AUDIO_EXTENSIONS.contains(&e.to_lowercase().as_str()))
        .unwrap_or(false)
}
